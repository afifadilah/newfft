# How to install (DEFAULT or BASIC USAGE)
	* git clone https://github.com/teamsyntaxid/bot-ig.git
	* cd bot-ig
	* unzip node_modules.zip
	* node index.js
	* Then select the tool you want to use!
<br/>

# For PC/Laptop ONLY:
	* Download GIT for Windows	(https://git-scm.com/download/) *Choose WIN & 32bit/64bit
	* Download NodeJS 			(https://nodejs.org/en/download/) *Choose .msi & 32bit/64bit
	* INSTALL GIT for Windows & NodeJS
	* Download File on Github (https://github.com/teamsyntaxid/bot-ig.git)
	* Extract File bot-ig-master and enter the folder
	* Right Click on Mouse, Then Select "Git Bash Here" (Make sure you are in the bot-ig folder!!!)
	* Then type: unzip node_modules.zip
	* To View The Contents Of a folder in bash, type: "ls" (without "")
	* To Run The Program in bash, type: "node index.js" (without "")
	* Then select the tool you want to use!
<br/>

# For TERMUX ONLY:
	* Install Termux (PlayStore)
	* Open Termux and Wait for Automatic Install of Termux.
	* pkg install git
	* pkg install nodejs
	* git clone https://github.com/gegeup1/fefet
	* cd bot-ig
	* unzip node_modules.zip
	* ls
	* node index.js
	* Then select the tool you want to use!
<br/>
# Pake c9.io :
	* 1. nvm install node
	* 2. git clone https://github.com/gegeup1/fefet
	* 3. cd ig-tools<br/>
	* 4. unzip node_modules.zip
	* 5. node ig.js
	* 6. insert username & pass
	* 7. insert usenem target (jangan pake @ iyh)
	* 8. insert bacotan fftnya & Milisecondnya (fft yg ini gaada ittywnya jadi otomatis lu ngefollow 1x/milisecond yg lu input)
<br/>

<br/>
# Pake Termux :
	* 1. pkg install nodejs-lts
	* 2. pkg install php
	* 3. pkg install bash
	* 4. pkg install git
	* 5. git clone https://github.com/gegeup1/fefet
	* 6. cd ig-tools
	* 7. unzip node_modules.zip
	* 8. node ig.js
	* 9. insert username & pass
	* 10. insert usenem target (jangan pake @ iyh)
	* 11. insert bacotan fftnya & Milisecondnya (fft yg ini gaada ittywnya jadi otomatis lu ngefollow 1x/milisecond yg lu input)
<br/>

# INFORMATION:
	* dellallphoto		"Delete All Post IG"			(WORK & TESTED)
	* fah				"SELECTED WITH HASTAG IG"		(WORK & TESTED)
	* fftauto			"SELECTED WITH TARGET IG"		(WORK & TESTED)
	* flaauto			"SELECTED WITH LOCATION IG"		(WORK & TESTED)
	* flmauto			"SELECTED WITH MEDIA IG"		(WORK & TESTED)
	* unfollall			"UNFOLOW ALL FOLLOWING IG"		(WORK & TESTED)
	* unfollnotfollback	"UNFOLLOW NOT FOLLOWBACK IG"	(WORK & TESTED)
	* botlike			"LIKE/LOVE TIMELINE IG"			(WORK & TESTED)
	* botlike2			"LIKE/LOVE TIMELINE IG"			(WORK & TESTED)
<br/>

# WARNING
	"Use tools at your own risk!!!"
	"Use this Tool for personal use, not for sale!!!"
	"Make sure your account is not in private to use this tool!!!"
<br/>

# UPDATE
	1. Fix Error No Detect Followers Target
    2. Input Target/delay Manual (ITTYW)
    3. + Improvements In Display Program
<br/>

# SPECIAL THANKS TO:
	* Code by Ccocot (ccocot@bc0de.net)
	* Fixing and Testing by Putu Syntax
	* SGB TEAM REBORN
	* BC0DE.NET | NAONLAH.NET - WingKocoli

Buat yg error' fftnya masukkan command ini.
<br/>
npm install https://github.com/gegeup1/instagram-private-api
<br/>
atau
<br/>
npm install https://github.com/huttarichard/instagram-private-api


# Text Comment:
likeback & folback ya :D|follback ya :)|salken follback & likeback ya :)| salken, boleh minta follback & likeback|udah aku follow, boleh minta follback ngak :) hehe|minta follback & like back yah, makasih hehe|nice pict, boleh minta follback & likesback nga?|udah aku follback ya , bisa bantu follback ngak :D|wah keren :), btw udah aku follow nih, bisa follback ngak|udah aku follow dan like bisa minta follback dan likebacknya hehe :)


like back & folback ya 😀 | follback & like back | follback ya 😀 | salken follback & like back ya 😀 | salken , boleh minta follback & like back 😀 | follow back yah 😀 | udah aku follow & likes 😀 , boleh minta follback & likes back ya? | udah aku follow, boleh minta follback ngak 😀 hehe | follback yaa :) | follback aku dong hehe 😀| salken , follback aku ya | udah aku follow nih, boleh minta follback nga? | orang mana, boleh minta follback & like back nga ? | mari berteman , follback & likes back yah :) | boleh minta follback? hehe 😀| minta follback & like back yah, makasih hehe | nice pict, boleh minta follback & likes back nga? | udah aku follback ya , bisa bantu follback ngak 😀? | udah aku follow nih 😀 , bantu follback yah 😀 | wah keren 😀 , btw udah aku follow nih , bisa follback ngak 😀? | like back dan Follow back ya🙏 | follback dan like back🙏 | follback ya👌 | salken, follback dan like back ya👍 | salam kenal follback dan likeback ya 😀👍 | orang mana? follback dan likeback ya👍 | salken ya, boleh minta follback dan likeback? | follback yo | follbackk | follback dan like back ya 😀 | followback ya | udah aku follow dan like bisa minta follback dan likebacknya hehe :) | follback dan likeback yo 😀 udah aku follow kok | follback dan likeback 😀 sudah aku follow dan like | bisa minta follow back 😀 hehe? | followback yo 😀 | salken, follback ya 🙂 | salken, follback aku yah | salken, btw follback ya | salken, follback juga yah hehe | salamkenal, follback yah hehe | bisa follback ? | follback yow | follback yapp | Follback hihihihi | follbackk saya ya 🙂 | Orang mana 😀, like back dan Follback ya | Salam kenal 😀 hehe likeback dan follback ya | Salken ya 😀 like back dan follback ya | Mari berteman 😀,like back dan follback ya | Orang mana 😀, Salam kenal ya , likeback dan Follback yaa | Orang mana 😀?, likeback dan Follback dong | Namanya siapa, Salam kenal ya, like back dan follback 
